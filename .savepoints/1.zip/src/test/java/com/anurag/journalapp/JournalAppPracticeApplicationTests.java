package com.anurag.journalapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JournalAppPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
